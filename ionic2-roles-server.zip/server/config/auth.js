module.exports = {  
  'secret': 'eypZAZy0CY^g9%KreypZAZy0CY^g9%Kr',
}