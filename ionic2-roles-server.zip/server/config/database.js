module.exports = {
	'url': 'mongodb://<username>:<password>@ds025379.mlab.com:25379/yourdb'
}